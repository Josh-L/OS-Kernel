#ifndef __DUMMY_PROCESSES__
#define __DUMMY_PROCESSES__

#include "memory/rtx_inc.h"

VOID test_proc_1();
VOID test_proc_2();
VOID test_proc_3();
VOID test_proc_4();
VOID test_proc_5();
VOID test_proc_6();
#endif