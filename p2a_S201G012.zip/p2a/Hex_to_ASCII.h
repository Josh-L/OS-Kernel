#ifndef _HEX_TO_ASCII_
#define _HEX_TO_ASCII_

#include "memory/rtx_inc.h"
VOID printHexAddress(UINT32 hexAddress);

#endif
