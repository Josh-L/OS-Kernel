#ifndef __NULL_PROCESS__
#define __NULL_PROCESS__

#include "memory/rtx_inc.h"

VOID null_process();
#endif