Group # = G012
Directory contents: timer0 - Contains timer0.c and all relevant files to build timer.s19
					uart1  - Contains uart1.c and all relevant files to build uart1.s19
					memory - Contains memory.c, memory.h, and all relevant files to build memory.s19
					
Build instructions: cd into appropriate directory and type "make clean" followed by "make". Upload *.s19 file to Coldfire board to run.