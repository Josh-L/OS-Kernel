#ifndef _HEX_TO_ASCII_
#define _HEX_TO_ASCII_

#include "rtx_inc.h"
VOID printHexAddress(UINT32 hexAddress);

#endif
